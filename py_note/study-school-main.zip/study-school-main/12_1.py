speed = 300000.0
distance = 40000000000000.0

secs = distance/speed
light_year = secs/(60.0*60.0*24.0*365.0)

print(light_year,"광년")