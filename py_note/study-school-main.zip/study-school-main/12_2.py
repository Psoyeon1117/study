PI = 3.14
r = 5
h = 10

volume = PI*r*r*h
print(volume)