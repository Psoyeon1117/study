weight = float(input("몸무게를 kg단위로 입력하시오: "))
heiht = float(input("키를 미터단위로 입력하시오: "))
BMI = weight/(heiht*heiht)
print("당신의 BMI=", BMI)